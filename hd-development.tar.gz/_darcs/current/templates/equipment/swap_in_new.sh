mv create.html     create.html_old
mv edit.html       edit.html_old

mv create.html_new create.html
mv edit.html_new   edit.html
